
INTRODUCTION
============

These examples are re-writes of the CLIPSJNI[1] examples (version 0.1) by
Gary Riley. The purpose is to show how to add a GUI to a CLIPS application.

CLIPSJNI uses the built-in Java Swing library to provide GUI capabilities.
I have used wxPython[2] instead of the built-in Tk/Tkinter packages that
comes with Python. The reason for that is personal preference, nothing else.
If you know any of the other Python GUI toolkits you can probably quite
easily modify these examples to work with them.


LICENSES
========
The Python programs included in this package are distributed under the BSD
license.

The .clp files was taken as-is from the CLIPSJNI package and are
re-distributed here with kind permission from the author. Visit CLIPS' web
page[3] for license information.


PREREQUISITES
=============

In order to run the examples you will need to have a working Python
installation with the PyCLIPS and wxPython libraries installed.

First, go to the Python web page[4] and download and install the latest
stable Python version.

Next, go to the wxPython web page[2] and download and install the latest
stable version of the wxPython runtime. Make sure to select a version that
fits your Python installation.

Also, if you plan to make GUIs yourself, you should download the Docs, Demo,
Samples, etc. package. It contains, among other things, the XRCEd tool which
I've used to construct the GUIs.

Next, go to the PyCLIPS web page[5] and download and install the latest
stable version (1.0.6 or later is required).

All of the web pages mentioned above contains links to instructions and
everything else you might need to get the separate installations working.


RUNNING THE EXAMPLES
====================

Unzip the contents of this package in a folder on your PYTHONPATH. In the
illustration below (using Windows) I've used C:\Program\CLIPS\PyCLIPS\examples.
The result should be:

C:\Program\CLIPS\PyCLIPS\examples\README.txt
C:\Program\CLIPS\PyCLIPS\examples\AutoDemo\autodemo.clp
C:\Program\CLIPS\PyCLIPS\examples\AutoDemo\AutoDemo.wx.py
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\Game01.txt
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\Game02.txt
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\Game03.txt
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\Game04.txt
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\Game05.txt
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\solve.clp
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\sudoku.clp
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\SudokuDemo.wx.py
C:\Program\CLIPS\PyCLIPS\examples\SudokuDemo\SudokuDemo.xrc
C:\Program\CLIPS\PyCLIPS\examples\WineDemo\winedemo.clp
C:\Program\CLIPS\PyCLIPS\examples\WineDemo\WineDemo.wx.py
C:\Program\CLIPS\PyCLIPS\examples\WineDemo\WineDemo.xrc

To run the WineDemo example you simply open a console, enter:

C:\>cd \Program\CLIPS\PyCLIPS\examples\WineDemo
C:\Program\CLIPS\PyCLIPS\examples\WineDemo>python WineDemo.wx.py

and the application should pop right up.

If you have any problems please ask in the PyCLIPS Help forum.
If you find any bugs, please report them in the PyCLIPS Bug tracker.

Enjoy!

Johan Lindberg, 2008-01-23
johanlindberg@users.sourceforge.net

[1] CLIPSJNI can be downloaded from http://groups.google.com/group/CLIPSESG/files
[2] http://www.wxpython.org
[3] http://sourceforge.net/projects/clipsrules/
[4] http://www.python.org/
[5] http://sourceforge.net/projects/pyclips
