
# Copyright (c) 2008, Johan Lindberg [johan@pulp.se]
# 
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
# 
#   * Redistributions of source code must retain the above copyright notice,
#     this list of conditions and the following disclaimer.
#   * Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
#   * Neither the name of the <ORGANIZATION> nor the names of its
#     contributors may be used to endorse or promote products derived from
#     this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
# OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import sys

import clips

import wx
import wx.xrc

class WineDemo(wx.App):
    def OnInit(self):
        # Load the Wine Expert System
        clips.Load("winedemo.clp")
        
        # Load the GUI from WineDemo.xrc
        resource = wx.xrc.XmlResource('WineDemo.xrc')
        self.frame = resource.LoadFrame(None, 'WineDemoFrame')
        
        # Store references to widgets that are being used at run-time.
        # wx.Choice widgets in Preferences
        self.color = wx.xrc.XRCCTRL(self.frame, 'Preferences_Color_Choice')
        self.body = wx.xrc.XRCCTRL(self.frame, 'Preferences_Body_Choice')
        self.sweetness = wx.xrc.XRCCTRL(self.frame, 'Preferences_Sweetness_Choice')
        
        # wx.Choice widgets in Meal
        self.maincourse = wx.xrc.XRCCTRL(self.frame, 'Meal_MainCourse_Choice')
        self.sauce = wx.xrc.XRCCTRL(self.frame, 'Meal_Sauce_Choice')
        self.flavor = wx.xrc.XRCCTRL(self.frame, 'Meal_Flavor_Choice')
        
        # wx.ListCtrl widget for Recommendations
        self.recommendations = wx.xrc.XRCCTRL(self.frame, 'WineDemoRecommendations')
        
        # Create 2 columns in the wx.ListCtrl
        self.recommendations.InsertColumn(0, "Wine")
        self.recommendations.InsertColumn(1, "Recommendation weight", wx.LIST_FORMAT_RIGHT)
        
        # Bind choice events to the calculateRecommendation function
        self.frame.Bind(wx.EVT_CHOICE, self.calculateRecommendation, self.color)
        self.frame.Bind(wx.EVT_CHOICE, self.calculateRecommendation, self.body)
        self.frame.Bind(wx.EVT_CHOICE, self.calculateRecommendation, self.sweetness)
        self.frame.Bind(wx.EVT_CHOICE, self.calculateRecommendation, self.maincourse)
        self.frame.Bind(wx.EVT_CHOICE, self.calculateRecommendation, self.sauce)
        self.frame.Bind(wx.EVT_CHOICE, self.calculateRecommendation, self.flavor)
        
        # Calculate an initial recommendation based on default values
        self.calculateRecommendation(None)
        
        # Bind the close event to the exit function and show the GUI
        self.frame.Bind(wx.EVT_CLOSE, self.exit)
        self.frame.Show(True)
        
        return True
        
    def calculateRecommendation(self, event):
        """
        Calculates a recommendation based on values in the wx.Choice
        widgets and updates the wx.ListCtrl accordingly.
        """
        
        clips.Reset()
        
        # Assert the appropriate attributes based on the values selected
        # in the GUI
        color = self.color.GetStringSelection()
        if color == "Red":
            clips.Assert("(attribute (name preferred-color) (value red))")
            
        elif color == "White":
            clips.Assert("(attribute (name preferred-color) (value white))")
            
        else:
            clips.Assert("(attribute (name preferred-color) (value unknown))")
            
            
        body = self.body.GetStringSelection()
        if body == "Light":
            clips.Assert("(attribute (name preferred-body) (value light))")
            
        elif body == "Medium":
            clips.Assert("(attribute (name preferred-body) (value medium))")
            
        elif body == "Full":
            clips.Assert("(attribute (name preferred-body) (value full))")
            
        else:
            clips.Assert("(attribute (name preferred-body) (value unknown))")
            
            
        sweetness = self.sweetness.GetStringSelection()
        if sweetness == "Dry":
            clips.Assert("(attribute (name preferred-sweetness) (value dry))")
            
        elif sweetness == "Medium":
            clips.Assert("(attribute (name preferred-sweetness) (value medium))")
            
        elif sweetness == "Sweet":
            clips.Assert("(attribute (name preferred-sweetness) (value sweet))")
            
        else:
            clips.Assert("(attribute (name preferred-sweetness) (value unknown))")
            
            
        maincourse = self.maincourse.GetStringSelection();
        if maincourse in ["Beef", "Pork", "Lamb"]:
            clips.Assert("(attribute (name main-component) (value meat))")
            clips.Assert("(attribute (name has-turkey) (value no))")
            
        elif maincourse == "Turkey":
            clips.Assert("(attribute (name main-component) (value poultry))")
            clips.Assert("(attribute (name has-turkey) (value yes))")
            
        elif maincourse in ["Chicken", "Duck"]:
            clips.Assert("(attribute (name main-component) (value poultry))")
            clips.Assert("(attribute (name has-turkey) (value no))")
            
        elif maincourse == "Fish":
            clips.Assert("(attribute (name main-component) (value fish))")
            clips.Assert("(attribute (name has-turkey) (value no))")
            
        elif maincourse == "Other":
            clips.Assert("(attribute (name main-component) (value unknown))")
            clips.Assert("(attribute (name has-turkey) (value no))")
            
        else:
            clips.Assert("(attribute (name main-component) (value unknown))")
            clips.Assert("(attribute (name has-turkey) (value unknown))")
            
            
        sauce = self.sauce.GetStringSelection()
        if sauce == "None":
            clips.Assert("(attribute (name has-sauce) (value no))")
            
        elif sauce == "Spicy":
            clips.Assert("(attribute (name has-sauce) (value yes))")
            clips.Assert("(attribute (name sauce) (value spicy))")
            
        elif sauce == "Sweet":
            clips.Assert("(attribute (name has-sauce) (value yes))")
            clips.Assert("(attribute (name sauce) (value sweet))")
            
        elif sauce == "Cream":
            clips.Assert("(attribute (name has-sauce) (value yes))")
            clips.Assert("(attribute (name sauce) (value cream))")
            
        elif sauce == "Other":
            clips.Assert("(attribute (name has-sauce) (value yes))")
            clips.Assert("(attribute (name sauce) (value unknown))")
            
        else:
            clips.Assert("(attribute (name has-sauce) (value unknown))")
            clips.Assert("(attribute (name sauce) (value unknown))")
            
            
        flavor = self.flavor.GetStringSelection()
        if flavor == "Delicate":
            clips.Assert("(attribute (name tastiness) (value delicate))")
            
        elif flavor == "Average":
            clips.Assert("(attribute (name tastiness) (value average))")
            
        elif flavor == "Strong":
            clips.Assert("(attribute (name tastiness) (value strong))")
            
        else:
            clips.Assert("(attribute (name tastiness) (value unknown))")
            
        clips.Run()
        
        # Clear the wx.ListCtrl...
        self.recommendations.DeleteAllItems()
        
        # ...and re-populate it with values
        row = 0
        clips.FindModule("WINES").SetCurrent()
        for fact in clips.Eval("(get-wine-list)"):
            value = fact.Slots["value"]
            certainty = int(fact.Slots["certainty"])
            
            self.recommendations.InsertStringItem(row, value)
            self.recommendations.SetStringItem(row, 1, str(certainty))
            
            row += 1
            
        # We have to re-specify the widths because DeleteAllItems sets
        # them back to default.
        self.recommendations.SetColumnWidth(0, 200)
        self.recommendations.SetColumnWidth(1, 200)
        
        
    def exit(self, event):
        """
        Destroys the GUI and exits the application.
        """
        
        self.frame.Destroy()
        sys.exit(0)
        
        
if __name__ == '__main__':
    app= WineDemo(0)
    app.MainLoop()
    